<?php
require_once('../Model/user-info-model.php');
    $name= $_REQUEST['name'];
    $result = searchdeliveryperson($name);
    if(mysqli_num_rows($result)>0){
        echo"<table width=\"85%\" border=\"1\" cellspacing=\"0\" cellpadding=\"15\">
     <tr>
         <td>
             Name
         </td>
         <td>
             Username
         </td>
         <td>
             Email
         </td>
         <td>
             Action
         </td>
         <hr width=auto><br>
     </tr>";
         while($w=mysqli_fetch_assoc($result)){
             $userid=$w['UserID'];
             $name=$w['Fullname'];
             $username=$w['Username'];
             $email=$w['Email'];
             echo "    
             <tr><td>$name</td>
             <td>$username</td>
             <td>$email</td> 
             <td><a href=\"view-information.php?id={$userid}\">Show Details</a></td>          
             </tr>";
         }
     }else{
         echo"<tr><td align=\"center\">No Delivery Person Found</td></tr>";
     }
?>