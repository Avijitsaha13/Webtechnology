<?php
 require_once('../Model/user-info-model.php');
 $id = $_COOKIE['id'];
 $password=$_REQUEST['password'];
 $result=checkpassword($password,$id);
 if(mysqli_num_rows($result)>0){
    echo"Password Matched";
 }else{
    echo"Password Not Matched";
 }
?>