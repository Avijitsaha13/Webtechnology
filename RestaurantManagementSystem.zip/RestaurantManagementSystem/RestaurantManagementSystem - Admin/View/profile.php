<?php 
session_start();
if(!isset($_COOKIE['flag'])) header('location:sign-in.php?err=accessDenied');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/profilebg.css">
</head>
<body>
<?php require_once('header.php');?>
<br><br>
    <table width="18%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td align=center>
                <a class="y"href="view-information.php"><button name="y">&nbsp&nbsp&nbsp&nbsp View Information &nbsp&nbsp&nbsp</button></a>
                <br><br>
                <a class="y"href="edit-information.php"><button name="y">&nbsp&nbsp&nbsp&nbsp&nbsp Edit Information &nbsp&nbsp&nbsp&nbsp</button></a>
                <br><br>
                <a class="y"href="update-pfp.php"><button name="y">Update Profile Picture&nbsp</button></a>
                <br><br>
                <a class="y"href="update-password.php"><button name="y">&nbsp&nbsp&nbsp Update Password &nbsp&nbsp&nbsp</button></a>
            </td>
        </tr>
    </table>
    <?php require_once('footer.php');?>
</body>
</html>