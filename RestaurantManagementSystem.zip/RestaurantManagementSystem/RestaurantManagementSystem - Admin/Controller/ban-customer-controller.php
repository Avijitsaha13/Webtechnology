<?php

    require_once('../Model/user-info-model.php'); 
    
    $id = $_GET['id'];
    
     if(banCustomer($id)) header('location:../View/ban-customer.php');

?>