<?php

    require_once('database.php');

    $row;

    function addItem($itemName, $category, $price, $pic){

        $con = dbConnection();
        $sql = $con -> prepare ("insert into Menu values('', ? , ?, 0, ?, ?)");
        $sql -> bind_param("ssis", $itemName, $category, $price, $pic);

        if($sql -> execute()) return true;
        else return false;
        
    }

    function getAllItem(){

        $con = dbConnection();
        $sql = "select * from Menu;";
    
        $result = mysqli_query($con,$sql);
        return $result;

    }

    function itemInfo($id){

        $con=dbConnection();
        $sql="select * from Menu where ItemID='$id'";

        $result=mysqli_query($con,$sql);
        $row=mysqli_fetch_assoc($result);

        return $row;
        
    }
    function updateItemInfo($id, $itemName, $category, $price){

        $con = dbConnection();
        $sql = $con -> prepare ("update Menu set ItemName = ?, Category = ?, Price = ? where ItemID = ?");
        $sql -> bind_param("ssss", $itemName, $category, $price, $id);     

        if($sql -> execute()===true) return true;
        else return false; 
        
    }

    function deleteItem($id){

        $con = dbConnection();
        $sql = "delete from Menu where ItemID = '$id'";
             
        if(mysqli_query($con,$sql)) return true;
        else return false; 

    }

?>