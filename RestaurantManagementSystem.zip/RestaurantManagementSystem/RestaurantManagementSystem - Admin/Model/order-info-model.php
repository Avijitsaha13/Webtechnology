<?php

    require_once('database.php');

    $row;

    function getAllOrder(){

        $con = dbConnection();
        $sql = "select * from OrderInfo;";
    
        $result = mysqli_query($con,$sql);
        return $result;

    }

?>