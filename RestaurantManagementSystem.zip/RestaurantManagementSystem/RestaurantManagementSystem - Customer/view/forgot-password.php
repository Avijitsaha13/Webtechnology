<?php

$error_msg = '';

if (isset($_GET['err'])) {

    $err_msg = $_GET['err'];

    switch ($err_msg) {
        case 'notFound': {
                $error_msg = "Email does not exist in our database.";
                break;
            }
        case 'accessDenied': {
                $error_msg = "Please provide an email first.";
                break;
            }
        case 'empty': {
                $error_msg = "Email can not be empty.";
                break;
            }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="css/sign-up.css">
    <link rel="stylesheet" href="css/textbox.css">
    <link rel="stylesheet" href="css/return.css">
    <link rel="stylesheet" href="css/button.css">
    <style>
        tr {
            background-color: LavenderBlush;
        }
    </style>
</head>

<body>
    <?php require 'header.php'; ?>

    <table width="27%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form method="post" action="../controller/forgot-password-controller.php" novalidate autocomplete="off"
                    onsubmit="return isValid(this);">

                    <h1>Password Assistance</h1>

                    <div class="textbox-container">
                        <b>Email:</b>
                        <input type="email" id="email" name="email" placeholder="Enter Your Email"
                            onkeyup="isValidEmail()">
                    </div>
                    <?php if (strlen($error_msg) > 0) { ?>
                        <br><br>
                        <font color="red"  align="center">
                            <?= $error_msg ?>
                        </font>
                    <?php } ?>
                    <br>
                    <font color="red" align="center" id="emailError"></font><br>
                    <button class="b2" name="submit">Continue</button>


                </form>
            </td>
        </tr>
    </table>
    <br><br>

    <center><a class="c" href="sign-in.php"><button name="c">Go Back</button></a></center>

    <script src="javascript/forgot-password.js"></script>
    <script>
        function isValidEmail() {

            let email = document.getElementById("email").value;

            let xhttp = new XMLHttpRequest();
            xhttp.open('GET', '../controller/get-info-controller.php?email=' + email, true);
            xhttp.send();

            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText)
                    if (this.responseText != "1") {
                        document.getElementById("emailError").innerHTML = "";
                    }
                    else {
                        document.getElementById("emailError").innerHTML = "Email not found";
                    }
                }
            }
        }
    </script>

    <?php require 'footer.php'; ?>


</body>

</html>