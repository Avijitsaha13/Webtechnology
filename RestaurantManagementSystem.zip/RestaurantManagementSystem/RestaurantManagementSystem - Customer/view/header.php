<html>
<head>
<style>
body {
  background-color:  Indigo;
}

h1 {
  color:  Indigo;
  
}

h3 {
  color:  Indigo;
  
}
</style>
</head>
<body>
  
<center>
  <h1>PRIMROSE</h1>
</center>

<center>
  <h3><b>Where Good Food Meets Great Moments</b></h3><br>
</center>


<!--<hr style = "height:2px;border-width:0;color:Lavender;background-color:Lavender"> 
<hr style = "height:2px;border-width:0;color:Lavender;background-color:Lavender">-->

<br>

</body>
</html>