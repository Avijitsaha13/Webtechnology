<?php

    require_once('database.php');

    $row;
    function getAllReviews($id){

        $con = dbConnection();
        $sql="select * from CustomerReview where ItemID = '{$id}' and Status = 'Active'";

        $result=mysqli_query($con,$sql);
        return $result;
    }
    function postReview($itemID, $userID, $review, $status){

        $con = dbConnection();
        $sql = $con -> prepare("insert into CustomerReview values('', ?, ?, ?, ?)");
        $sql -> bind_param("ssss", $itemID, $userID, $review, $status); 

        if($sql -> execute()) return true;
        else return false;
        
    }

    function deleteReview($id){

        $con = dbConnection();
        $sql = "delete from CustomerReview where ReviewID = '$id'";
             
        if(mysqli_query($con,$sql)) return true;
        else return false; 

    }


?>