<?php

    require_once('database.php');

    $row;
    function createOrder($customerName, $deliveryManName, $address, $bill, $deliveryDate, $orderDate, $orderStatus){

        $con = dbConnection();
        $sql = $con -> prepare ("insert into OrderInfo values('',? ,? ,?, ?, ?, ?, ?)");
        $sql -> bind_param("sssdsss", $customerName, $deliveryManName, $address, $bill, $deliveryDate, $orderDate, $orderStatus);

        if($sql -> execute()) return true;
        else return false;
        
    }
    function getAllOrder(){

        $con = dbConnection();
        $sql = "select * from OrderInfo;";
    
        $result = mysqli_query($con,$sql);
        return $result;

    }

    function getOrderHistory($fullname){

        $con = dbConnection();
        $sql = $con -> prepare ("select * from OrderInfo where CustomerName = ? and OrderStatus = 'Completed';");
        $sql -> bind_param("s", $fullname);
        $sql -> execute();

        $result = $sql -> get_result();
        return $result;

    }

?>