<?php

    require_once('database.php');

    $row;
    function sendComplaint($fullname, $complaint){

        $con = dbConnection();
        $sql = $con -> prepare("insert into Complaint values('', ?, ?)");
        $sql -> bind_param("ss", $fullname, $complaint);

        if($sql -> execute()) return true;
        else return false;
        
    }

?>