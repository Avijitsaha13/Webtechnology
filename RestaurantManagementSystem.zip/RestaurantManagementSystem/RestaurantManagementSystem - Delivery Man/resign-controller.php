<?php

    require_once('user-info-model.php');
            
    $id = $_COOKIE['id'];
    $row = userInfo($id);

    $password = $_POST['password'];

    if(empty($password)){
        header('location:resign.php?err=empty'); 
        exit();
    }

    if($password != $row['Password']){
        header('location:resign.php?err=mismatch'); 
        exit();
    }

    $status = resign($id);
    if($status) header('location:resign.php?success=confirmed');

?>