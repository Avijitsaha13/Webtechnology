<?php require_once('user-info-model.php');
 $row = userInfo($_COOKIE['id']); ?><br><br>
<center>
    Restaurant Management System <br><br>
    <a href="about-us.php">About Us</a> &nbsp;&nbsp;&nbsp; 
</center>
<br><br>