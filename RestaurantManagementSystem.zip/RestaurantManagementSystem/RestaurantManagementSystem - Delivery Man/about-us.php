<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
</head>
<body>
    <br><br><br>
    <center>
    <h1>About Us</h1>
    <hr width=250><br><br>
    Welcome to our Restaurant Management System. <br><br>
    Our website aims to be a culinary haven where passion for food meets exceptional hospitality. We are more than just a restaurant; <br> we are a destination where every meal is a memorable experience. Your satisfaction is our utmost priority, and we value your <br> feedback.<br><br><br>
    Thank you for choosing our website. Where Good Food Meets Great Moments.<br><br><br>
    Meet the Developers<br><br>
    <hr width=500><br><br>

    <table border="0" width=85% cellpadding=10>

    <tr align="center">
        <td>Noshin Farzana</td>
        <td>Avijit Saha Anto</td>
        <td>Arik Ahmed Zelan</td>
        <td>Sadikul Mobasshir</td>
    </tr>
    <tr align="center">
        <td>21-44647-1</td>
        <td>21-44630-1</td>
        <td>21-44600-1</td>
        <td>21-44415-1</td>
    </tr>

    </table>

    </center>
</body>
</html>