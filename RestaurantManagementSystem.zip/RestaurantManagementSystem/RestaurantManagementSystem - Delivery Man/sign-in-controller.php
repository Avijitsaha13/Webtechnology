<?php
session_start();

    require_once('user-info-model.php');

    

        $email = $_POST['email'];
        $password = $_POST['password'];

        if(strlen(trim($email)) == 0 || strlen(trim($password)) == 0){

            header('location:sign-in.php?err=empty');
            return;

        }
    

        $status = login($email, $password);

        if($status!=false){
            
            if($status['Role'] == "Delivery Man" and ($status['Status'] == "Active" or $status['Status'] == "Resigning")){

                $_SESSION['LoggedIn'] = "true";
                setcookie("id", $status['UserID'], time()+3600*24*30, "/");
               header('location:deliveryman-home.php');

            }
            else header('location:sign-in.php?err=bannedUser');

        }else header('location:sign-in.php?err=mismatch');
        
    

?>